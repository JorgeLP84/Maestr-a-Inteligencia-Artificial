from pathlib import Path

from app.pdf_reader import extract_text_from_pdf
from app.chunk import split_pages
from app.embed import get_embedding
from app.store import add_documents, collection


DATA_FOLDER = Path("data")


def main():

    pdf_files = list(DATA_FOLDER.rglob("*.pdf"))

    print(f"PDF encontrados: {len(pdf_files)}")

    total_chunks = 0

    # Obtener documentos que ya están cargados
    existing_data = collection.get()

    existing_sources = set()

    for metadata in existing_data.get("metadatas", []):
        if metadata and "source" in metadata:
            existing_sources.add(metadata["source"])

    print(f"PDF ya cargados: {len(existing_sources)}")

    for pdf_path in pdf_files:

        # Si el PDF ya está en Chroma, lo saltamos
        if pdf_path.name in existing_sources:
            print(f"\nSaltando (ya cargado): {pdf_path}")
            continue

        print()
        print(f"Procesando: {pdf_path}")

        pages = extract_text_from_pdf(str(pdf_path))

        chunks = split_pages(pages)

        documents = []
        embeddings = []
        metadatas = []
        ids = []

        for index, item in enumerate(chunks):

            text = item["text"]

            print(
                f"  Generando embedding "
                f"{index + 1}/{len(chunks)}..."
            )

            embedding = get_embedding(text)

            documents.append(text)
            embeddings.append(embedding)

            relative_path = pdf_path.relative_to(DATA_FOLDER)

            metadatas.append({
                "source": pdf_path.name,
                "category": str(relative_path.parent),
                "page": item["page"],
                "chunk": item["chunk"]
            })

            ids.append(
                f"{pdf_path.name}-{index}"
            )

        if documents:

            add_documents(
                documents,
                embeddings,
                metadatas,
                ids
            )

        total_chunks += len(chunks)

        print(f"  Páginas: {len(pages)}")
        print(f"  Chunks: {len(chunks)}")

    print()
    print("================================")
    print("Carga terminada")
    print(f"PDF encontrados: {len(pdf_files)}")
    print(f"PDF que ya estaban cargados: {len(existing_sources)}")
    print(f"Chunks nuevos: {total_chunks}")
    print(f"Chunks totales en Chroma: {collection.count()}")
    print("================================")


if __name__ == "__main__":
    main()