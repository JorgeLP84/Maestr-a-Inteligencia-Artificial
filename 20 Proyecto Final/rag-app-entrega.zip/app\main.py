from pathlib import Path

from fastapi import FastAPI, File, UploadFile

from app.pdf_reader import extract_text_from_pdf
from app.chunk import split_pages
from app.embed import get_embedding
from app.store import add_documents, search_documents
from app.generate import generate_answer


app = FastAPI(title="Land Rover Postventa RAG")


@app.get("/health")
def health():
    return {
        "status": "ok",
        "message": "API funcionando correctamente"
    }


@app.post("/ingest")
async def ingest(file: UploadFile = File(...)):

    data_folder = Path("data")
    data_folder.mkdir(exist_ok=True)

    file_path = data_folder / file.filename

    content = await file.read()
    file_path.write_bytes(content)

    pages = extract_text_from_pdf(str(file_path))

    chunks = split_pages(pages)

    documents = []
    embeddings = []
    metadatas = []
    ids = []

    for index, item in enumerate(chunks):

        text = item["text"]

        embedding = get_embedding(text)

        documents.append(text)
        embeddings.append(embedding)

        metadatas.append({
            "source": file.filename,
            "page": item["page"],
            "chunk": item["chunk"]
        })

        ids.append(
            f"{file.filename}-{index}"
        )

    add_documents(
        documents,
        embeddings,
        metadatas,
        ids
    )

    return {
        "status": "ok",
        "filename": file.filename,
        "pages": len(pages),
        "chunks": len(chunks),
        "message": "Documento procesado y guardado en ChromaDB"
    }


@app.post("/query")
def query(question: str, top_k: int = 5):

    query_embedding = get_embedding(question)

    results = search_documents(
        query_embedding,
        top_k
    )

    documents = results["documents"][0]
    metadatas = results["metadatas"][0]
    distances = results["distances"][0]

    context_parts = []
    citations = []

    for i, (document, metadata, distance) in enumerate(
        zip(documents, metadatas, distances),
        start=1
    ):

        context_parts.append(
            f"[{i}] Fuente: {metadata['source']}, "
            f"página: {metadata['page']}, "
            f"chunk: {metadata['chunk']}\n"
            f"{document}"
        )

        citations.append({
            "id": i,
            "source": metadata["source"],
            "page": metadata["page"],
            "chunk": metadata["chunk"],
            "text": document,
            "score": distance
        })

    context = "\n\n".join(context_parts)

    best_distance = min(distances)

    if best_distance > 0.70:
        return {
            "answer": "No tengo evidencia suficiente en los documentos proporcionados para responder esta pregunta.",
            "citations": [],
            "abstained": True
        }

    answer = generate_answer(
        question,
        context
    )

    return {
        "answer": answer,
        "citations": citations,
        "abstained": "No tengo evidencia suficiente" in answer
    }