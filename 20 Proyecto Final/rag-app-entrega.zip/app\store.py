import chromadb

CHROMA_PATH = "./chroma"

client = chromadb.PersistentClient(path=CHROMA_PATH)

collection = client.get_or_create_collection(
    name="land_rover_postventa"
)


def add_documents(
    documents: list[str],
    embeddings: list[list[float]],
    metadatas: list[dict],
    ids: list[str]
):
    collection.add(
        documents=documents,
        embeddings=embeddings,
        metadatas=metadatas,
        ids=ids
    )


def search_documents(
    query_embedding: list[float],
    top_k: int = 5
):
    return collection.query(
        query_embeddings=[query_embedding],
        n_results=top_k
    )