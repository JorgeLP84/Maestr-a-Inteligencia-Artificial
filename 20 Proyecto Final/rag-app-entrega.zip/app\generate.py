import os

from dotenv import load_dotenv
from google import genai


load_dotenv()

client = genai.Client(
    api_key=os.getenv("GOOGLE_API_KEY")
)

GENERATION_MODEL = "gemini-3.5-flash"


def generate_answer(question: str, context: str):

    prompt = f"""
Eres un asistente especializado en Land Rover Postventa.

Responde la pregunta utilizando únicamente la información
proporcionada en el contexto.

Si el contexto no contiene información suficiente para responder,
debes decir exactamente:

"No tengo evidencia suficiente en los documentos proporcionados
para responder esta pregunta."

No inventes información y no utilices conocimiento externo.

Responde en español.

Cuando utilices información del contexto, indica la fuente
utilizando las referencias [1], [2], [3], etc.

PREGUNTA:
{question}

CONTEXTO:
{context}
"""

    response = client.models.generate_content(
        model=GENERATION_MODEL,
        contents=prompt
    )

    return response.text