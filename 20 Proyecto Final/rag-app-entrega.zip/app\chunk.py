def split_text(text: str, chunk_size: int = 300, overlap: int = 60):
    """
    Divide un texto en fragmentos de aproximadamente
    chunk_size palabras, manteniendo un traslape.
    """

    words = text.split()

    if not words:
        return []

    chunks = []
    start = 0

    while start < len(words):
        end = start + chunk_size
        chunk = " ".join(words[start:end])
        chunks.append(chunk)

        if end >= len(words):
            break

        start = end - overlap

    return chunks


def split_pages(pages, chunk_size: int = 300, overlap: int = 60):
    """
    Divide las páginas de un PDF en chunks,
    conservando el número de página y la posición del chunk.
    """

    results = []

    for page_number, page_text in enumerate(pages, start=1):

        page_chunks = split_text(
            page_text,
            chunk_size,
            overlap
        )

        for chunk_number, chunk in enumerate(page_chunks, start=1):

            results.append({
                "text": chunk,
                "page": page_number,
                "chunk": chunk_number
            })

    return results